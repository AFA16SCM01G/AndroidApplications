# Homework Index

- Assignment 1 – Temperature Converter

![ss](./src/hw1.png)

- Assignment 2 – Notepad

![ss](./src/hw2.png)

- Assignment 3 - Multi Notepad

![ss](./src/hw3.png)

- Assignment 4 - Stock Watch

![ss](./src/hw4.png)

- Assignment 5 - Know Your Government

![ss](./src/hw5-1.png)
![ss](./src/hw5-2.png)
